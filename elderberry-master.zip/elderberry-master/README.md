Overview
--------
This repository contains all the source files for the website for our Set.
This project is an exercise demonstrate the process of collaborate/social 
coding using GIT and GITHUB. 

Each project team should organize themselves so that the 
final state of the website is presentable and complete.   
For example, there should be no merge conflicts 
left in any of the source files.   

Subfolders:
----------
The Images folder contains all images used in the website.  
The Style folder contains style sheet for the website.

# elderberry
